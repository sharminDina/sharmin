<div class="footer">
<?php
echo "<hr>";
echo "<p>Copyright 1999-" . date("Y") ." &copy;   Powered by: RUST BUCKET</p>";
?>
</div>