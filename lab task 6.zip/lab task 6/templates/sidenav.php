<div class="sidenav">
    <a href="/WebTechCourse/Lab task 4">Dashboard</a>
    <a href="./view_profile.php">View Profile</a>
    <a href="./edit_profile.php">Edit Profile</a>
    <a href="./profile_picture.php">Change Profile Picture</a>
    <a href="./change_pass.php">Change Password</a>
    <a href="./logout.php">Logout</a>
</div>